function dispLog(varName)

maxVal = evalin('base',['maxlog(',varName,')']);
minVal = evalin('base',['minlog(',varName,')']);
overF = evalin('base',['noverflows(',varName,')']);
underF = evalin('base',['nunderflows(',varName,')']);

disp([maxVal, minVal, overF, underF]);
