%% Creating and Implementing LMS Algorithm to Filter out Cockpit Noise

%% Load Pre-saved Test Voice Data

% Load Test Audio Signal to be used as clean input and play this sample
% through the PC sound card
load mtlb
%sound(mtlb, Fs);
%pause(2);

%% Bring in Live Audio data from Data Acquisition Device (Soundcard)

% Use Data Acquisition Toolbox to bring data in from Soundcard. This
% example shows how streaming data can be brought into MATLAB from any data
% acquisition card that is supported by the Data Acquisition Toolbox.

% Set up Acquisition object with the desired sampling frequency, and add
% just 1 channel to acquire data from
ai = analoginput('winsound');
addchannel(ai,1);
set(ai, 'SampleRate', 8000);

% Acquire 5 seconds of data
set(ai, 'SamplesPerTrigger', 5*8000);
set(ai, 'TriggerType', 'immediate');
start(ai);
data = getdata(ai);
size(data);

%SET FLAG TO CHOOSE INPUT SOURCE
inputSource = 1; % set this as 1 for pre-saved audio, and 2 for audio from soundcard

% Select which dataset to use as the clean input signal to which noise is
% added. Comment 1 of the following 2 lines accordingly

if inputSource == 1
    audioInputSignal = mtlb; %Use pre-saved audio
else
    audioInputSignal = data; %Use audio captured from Soundcard
end



%% Create Random noise and filter it with an 'unknown' filtering process

% Observation noise signal corresponding to Engine noise
noise = randn(size(mtlb));

% 'Unknown' FIR system to be identified
b  = fir1(31,0.5);
noise_filtered  = filter(b,1,noise);
mtlb_noisy  = mtlb(1:length(noise_filtered)) + noise_filtered;

%% Plot the noisy spectrogram
subplot(1,2,1), spectrogram(mtlb_noisy,  128,120,256,'yaxis'); title('Noisy Audio')

%Play noisy signal
%sound(mtlb_noisy, Fs)
%pause(2)

%% Create and Implement LMS Adaptive Filter
% Create simple LMS/nLMS/RLS Filter to identify filtering process and
% remove the filtered noise from desired signal

% Define Adaptive Filter Parameters
filterLength = 32;
weights = zeros(1,filterLength);
step_size = 0.004;

% Initialize Filter's Operational inputs
output = zeros(1, length(mtlb_noisy));
err = zeros(1,length(mtlb_noisy));
input = zeros(1,filterLength);

% For Loop to run through the data and filter out noise
for n = 1: length(mtlb_noisy)

    %Get input vector to filter
    for k= 1:filterLength
        if ((n-k)>0)
            input(k) = noise(n-k+1);
        end
    end

    output(n) = weights * input';  %            <Output of Adaptive Filter
    err(n)  = mtlb_noisy(n) - output(n); %          <Error Computation
    weights = weights + step_size * err(n) * input; %           <Weights  Updation 

    %plot(weights); % Optional command to plot weights to visualize how
    %they change
end

% Plot the Clean Spectrogram
subplot(1,2,2), spectrogram(err, 128,120,256,'yaxis');title('Filtered Audio')

%% Play the filtered audio 

% The cleaned up audio signal is in this case the error signal
sound(err)




