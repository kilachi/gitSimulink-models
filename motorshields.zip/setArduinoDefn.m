function setArduinoDefn(buildInfo)
% Copyright 2014 The MathWorks, Inc. 
    buildInfo.addDefines('-DARDUINO=105'); % Add a Custom define to the build info
end
